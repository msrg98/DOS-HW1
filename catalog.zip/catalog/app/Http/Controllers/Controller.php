<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function search(Request $request)
    {
         $file = fopen(storage_path("databases/database.txt"), "r");
         $result = collect([]);
         while (!feof($file)) {
            $item = fgets($file);
	    $itemArray = explode(',', $item);
            if (count($itemArray) > 1 && substr($itemArray[4],0,-1) === $request->input('topic')){
		    $result->push(['id' => $itemArray[0], 'title' => $itemArray[1]]);
	    }
         }
	 fclose($file);
	 if (count($result) > 0)
       	    echo json_encode($result);
	 else
	    echo json_encode("fail");
    }

    public function lookUp(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r");
        $result = collect([]);
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(',', $item);
            if (intval($itemArray[0]) === intval($request->input('id'))) {
                echo json_encode(['id' => $itemArray[0], 'title' => $itemArray[1], 'stock' => $itemArray[2], 'price' => $itemArray[3], 'topic' => substr($itemArray[4],0,-1)]);
                break;
            }
        }
        fclose($file);
    }

    public function buy(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r");
        $result = collect([]);
        $lineNo = 0;
	$newText = "";
	$writeFlag = false;
        while (!feof($file)) {
            $lineNo++;
            $item = fgets($file);
            $itemArray = explode(',', $item);
	    if (intval($itemArray[0]) === intval($request->id)) {
		if (intval($itemArray[2]) > 0) {
	            $newStock = intval($itemArray[2])-1;
                    $newText = $newText.$itemArray[0].",".$itemArray[1].",".$newStock.",".$itemArray[3].",".$itemArray[4];
		    $writeFlag = true;
                }
                else{
                    $newText = $newText.$item;
		    $writeFlag = false;
		}
            }
            else {
                $newText = $newText.$item;
            }
	}
	fclose($file);
	$file = fopen(storage_path("databases/database.txt"), "w");
        fwrite($file,$newText);
        fclose($file);
        if ($writeFlag){
            echo json_encode("success");
        }
        else
            echo json_encode("failed");
    }
}
