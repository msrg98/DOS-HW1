<?php

namespace App\Http\Controllers;


use GuzzleHttp\Client;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Ixudra\Curl\Facades\Curl;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function search(Request $request) {
        $client = new Client();
        try
        {
        $response = $client->request('GET', 'http://192.168.56.101:8000/search?topic='.$request->input('topic'));
        echo $response->getBody();
        }
        catch (GuzzleHttp\Exception\ServerException $e) {
            $response = $e->getResponse();
            echo $responseBodyAsString = $response->getBody()->getContents();
        }
    }

    public function lookUp(Request $request) {
        $client = new Client();
        $response = $client->request('GET', 'http://192.168.56.101:8000/lookup?id='.$request->input('id'));
        echo $response->getBody();
        /*$response = Curl::to('http://192.168.56.101:8000/lookup?id='.$request->input('id'))
            ->returnResponseObject()
            ->get();
        echo $response->content;*/
    }

    public function buy(Request $request) {
        $client = new Client();
        $response = $client->request('POST', 'http://192.168.56.102:8000/buy', [
            'form_params' => [
                'id' => $request->input('id'),
            ]
        ]);
        echo $response->getBody();
    }
}
